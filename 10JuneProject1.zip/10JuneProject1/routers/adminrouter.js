const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc= require('../controllers/querycontroller')
const addressc=require('../controllers/addresscontroller')
const upload=require('../helpers/multer')

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/admin')
    }
}

router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/dashboard',handlelogin,regc.homepage)
router.get('/logout',regc.logout)
router.get('/banner',handlelogin,bannerc.bannerpage)
router.get('/bannerupdateform/:id',handlelogin,bannerc.bannerform)
router.post('/bannerupdateform/:id',upload.single('img'),bannerc.bannerupdate)
router.get('/service',handlelogin,servicec.service)
router.get('/serviceadd',handlelogin,servicec.serviceform)
router.post('/serviceadd',upload.single('img'),servicec.addservice)
router.get('/servicedelete/:id',handlelogin,servicec.servicedelete)
router.get('/servicestatus/:id',handlelogin,servicec.servicestaus)
router.get('/testi',handlelogin,testic.testipage)
router.get('/testidelete/:id',handlelogin,testic.testidelete)
router.get('/testistatus/:id',handlelogin,testic.testistatus)
router.get('/query',handlelogin,queryc.querypage)
router.get('/queryform/:id',handlelogin,queryc.queryform)
router.post('/queryform/:id',upload.single('attachment'),queryc.querysend)
router.post('/service',servicec.search)
router.post('/testi',testic.searchtesti)
router.get('/address',addressc.addresspage)
router.get('/addressupdate/:id',addressc.addressform)
router.post('/addressupdate/:id',addressc.addressupdate)


module.exports=router
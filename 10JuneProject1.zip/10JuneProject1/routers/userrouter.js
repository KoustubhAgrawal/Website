const router=require('express').Router()
const upload=require('../helpers/multer')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc= require('../controllers/querycontroller')
const Banner=require('../models/banner')
const Service=require('../models/service')
const Testi=require('../models/testi')
const Address=require('../models/address')
const addressc=require('../controllers/addresscontroller')


router.get('/',async(req,res)=>{
    const bannerRecord=await Banner.findOne()
    const serviceRecord=await Service.find({status:'Published'})
    const testiRecord=await Testi.find({status:'Published'}).sort({postedDate:-1})
    const addressRecord=await Address.findOne()
    res.render('index.ejs',{bannerRecord,serviceRecord,testiRecord,addressRecord})
})
router.get('/banner',bannerc.bannermoredeatils)
router.get('/testiform',testic.testiform)
router.post('/testiform',upload.single('image'),testic.testiadd)
router.post('/',queryc.queryadd)
router.get('/servicemdetails/:id',servicec.moredetails)

module.exports=router
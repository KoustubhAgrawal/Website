const Address=require('../models/address')


exports.addresspage=async(req,res)=>{
    const loginname=req.session.loginname
    const record=await Address.findOne()
    res.render('admin/address.ejs',{loginname,record})
}
exports.addressform=async(req,res)=>{
    const loginname=req.session.loginname
    console.log(req.params.id)
    const record= await Address.findById(req.params.id)

console.log(record)
   res.render('admin/addressform.ejs',{loginname,record})
}
exports.addressupdate=async(req,res)=>{
    const{add,tel,mobile,email,ig,link,snap,tweet} = req.body
    const id=req.params.id
    const loginname=req.session.loginname
    //const record=await Address.findById(id)
    await Address.findByIdAndUpdate(id,{address:add,landline:tel,mobile:mobile,email:email,insta:ig,link:link,snap:snap,twit:tweet})
    //res.render('admin/addressform.ejs',{loginname})
    res.redirect('/admin/address')
}
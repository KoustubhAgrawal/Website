const Service=require('../models/service')

exports.service=async(req,res)=>{
    const record=await Service.find().sort({postedDate:-1})
    const loginname=req.session.loginname
    const tservice=await Service.count()
    const unservice=await Service.count({status:'Unpublished'})
    const puservice=await Service.count({status:'Published'})
    res.render('admin/service.ejs',{loginname,record,tservice,unservice,puservice})
}
exports.serviceform=(req,res)=>{
    const loginname=req.session.loginname
    res.render('admin/serviceform.ejs',{loginname})
}
exports.addservice=(req,res)=>{
    const currendate=new Date()
    const{stitle,sdesc,smdetails}=req.body
    const filename =req.file.filename
    const record=new Service({title:stitle,desc:sdesc,img:filename,mdetails:smdetails,postedDate:currendate})
    record.save()
}
exports.servicedelete=async(req,res)=>{
    const id= req.params.id
    await Service.findByIdAndDelete(id)
    res.redirect('/admin/service')
}
exports.servicestaus=async(req,res)=>{
    const id=req.params.id
    const record=await Service.findById(id)
    let newstatus=null

    if(record.status=='Unpublished'){
        newstatus='Published'
    }else{
        newstatus='Unpublished'
    }
    await Service.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/service')
}
exports.search=async(req,res)=>{
    const{search}=req.body
    const loginname=req.session.loginname
    const record=await Service.find({status:search})
    const tservice=await Service.count()
    const unservice=await Service.count({status:'Unpublished'})
    const puservice=await Service.count({status:'Published'})
    res.render('admin/service.ejs',{loginname,record,tservice,unservice,puservice})
}
exports.moredetails=async(req,res)=>{
   // console.log(req.params.id)
    const id=req.params.id
    const record= await Service.findById(id)
    res.render('servicemdetails.ejs',{record})
}

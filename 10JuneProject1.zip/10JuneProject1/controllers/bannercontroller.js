const Banner=require('../models/banner')

exports.bannerpage=async(req,res)=>{
    try{
    const loginname=req.session.loginname
    const record=await Banner.findOne()
    res.render('admin/banner.ejs',{loginname,record})
    }catch(error){
        console.log(error.message)
    }
}
exports.bannerform=async(req,res)=>{
    try{
    const id=req.params.id
    const loginname=req.session.loginname
    const record=await Banner.findById(id)
    res.render('admin/bannerform.ejs',{loginname,record,message:''})
    }catch(error){
    console.log(error.message)
    }
}
exports.bannerupdate=async(req,res)=>{
    try{
    const{btitle,bdesc,bmdetails}=req.body
    const id=req.params.id
    const loginname=req.session.loginname
    const record=await Banner.findById(id)

    if(req.file){
    const filename=req.file.filename
    await Banner.findByIdAndUpdate(id,{title:btitle,desc:bdesc,img:filename,mdetails:bmdetails})
    }else{
        await Banner.findByIdAndUpdate(id,{title:btitle,desc:bdesc,mdetails:bmdetails})}
    res.render('admin/bannerform.ejs',{message:'Sucessfully updated',loginname,record})
    }catch(error){
    console.log(error.message)
    }
}
exports.bannermoredeatils=async(req,res)=>{
    const record=await Banner.findOne()
    res.render('banner.ejs',{record})
}
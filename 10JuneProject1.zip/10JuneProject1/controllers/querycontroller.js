const Query= require('../models/query')
const nodemailer=require('nodemailer')


exports.queryadd=(req,res)=>{
    const{email,query}=req.body
    const record= new Query({email:email,query:query})
    record.save()
}
exports.querypage=async(req,res)=>{
    const loginname=req.session.loginname
    const record=await Query.find().sort({status:1})
    res.render('admin/query.ejs',{loginname,record})
}
exports.queryform=async(req,res)=>{
    const record = await Query.findById(req.params.id)
    const loginname=req.session.loginname
    res.render('admin/queryform.ejs',{loginname,record})
}
exports.querysend=async(req,res)=>{
    const{qto,qfrom,qsubject,qbody}=req.body
    const path=req.file.path
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: 'koustubh788@gmail.com',
          pass: 'zgdkffferozcvtrg'
        }
      });
      //console.log('connectes to smtp server')
      const info = await transporter.sendMail({
        from: qfrom, // sender address
        to: qto, // list of receivers
        subject: qsubject, // Subject line
        text: qbody, // plain text body
        //html: "<b>Hello world?</b>", // html body
        attachments:[{
            path:path
        }]
      });
      //console.log('email sent')
      await Query.findByIdAndUpdate(req.params.id,{status:'Replied'})
      res.redirect('/admin/query')

}
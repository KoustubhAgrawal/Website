const Testi=require('../models/testi')


exports.testiform=(req,res)=>{
    res.render('testiform.ejs')
}
exports.testiadd=(req,res)=>{
    const{name,views}=req.body
    if(req.file){
        const filename=req.file.filename
        var record=new Testi({quotes:views,name:name,image:filename})}
    else{
        record=new Testi({quotes:views,name:name,image:'avatar.jpg'})
    }
    record.save()
    console.log(record)
}
exports.testipage=async(req,res)=>{
    const loginname=req.session.loginname
    const record= await Testi.find().sort({postedDate:-1})
    const ttesti=await Testi.count()
    const utesti=await Testi.count({status:'Unpublished'})
    const ptesti=await Testi.count({status:'Published'})
    res.render('admin/testi.ejs',{loginname,record,ttesti,utesti,ptesti})
}
exports.testidelete=async(req,res)=>{
    const id=req.params.id
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}
exports.testistatus=async(req,res)=>{
    const id=req.params.id
    const record=await Testi.findById(id)
    let newstatus=null
    if(record.status=='Unpublished'){
        newstatus='Published'
    }else{
        newstatus='Unpublished'
    }
    await Testi.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/testi')
}
exports.searchtesti=async(req,res)=>{
    const{search}=req.body
    const record= await Testi.find({status:search})
    const loginname=req.session.loginname
    const ttesti=await Testi.count()
    const utesti=await Testi.count({status:'Unpublished'})
    const ptesti=await Testi.count({status:'Published'})
    res.render('admin/testi.ejs',{loginname,record,ttesti,utesti,ptesti})
}
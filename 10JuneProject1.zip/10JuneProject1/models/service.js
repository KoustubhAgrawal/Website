const mongoose=require('mongoose')

const ServiceSchema=mongoose.Schema({
    title:String,
    img:String,
    desc:String,
    mdetails:String, 
    postedDate:Date,
    status:{type:String,default:'Unpublished'}
})

module.exports= mongoose.model('service',ServiceSchema)
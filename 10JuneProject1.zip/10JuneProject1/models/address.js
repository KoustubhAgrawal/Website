const mongoose =require('mongoose')


const AddressSchema =mongoose.Schema({
    address:String,
    landline:Number,
    mobile:Number,
    email:String,
    insta:String,
    link:String,
    snap:String,
    twit:String
})




module.exports=mongoose.model('address',AddressSchema)
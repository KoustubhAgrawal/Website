const mongoose=require('mongoose')


const testiSchema=mongoose.Schema({
    image:String,
    quotes:String,
    name:String,
    status:{type:String,default:'Unpublished'},
    postedDate:{type:String,default:new Date()},
})


module.exports= mongoose.model('testi',testiSchema)